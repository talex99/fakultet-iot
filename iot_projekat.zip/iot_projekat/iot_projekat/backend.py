from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Define the IP address of your robot
ROBOT_IP = '192.168.0.31'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/control', methods=['GET'])
def control_robot():
    direction = request.args.get('dir')
    print(direction)
    if direction == 'release':
        print("S")
        requests.get(f'http://{ROBOT_IP}/S')

    if direction == 'up':
        print("F")
        requests.get(f'http://{ROBOT_IP}/F')
    if direction == 'down':
        print("D")
        requests.get(f'http://{ROBOT_IP}/B')
    if direction == 'left':
        print("L")
        requests.get(f'http://{ROBOT_IP}/L')
    if direction == 'right':
        print("R")
        requests.get(f'http://{ROBOT_IP}/R')
   

    # Add handling for other directions (left, right, down) if needed
    # Add handling for other directions (left, right, down) if needed
    return '', 200

if __name__ == '__main__':
    app.run(debug=True)
